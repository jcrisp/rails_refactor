require 'spec_helper'

describe DummiesController do

end
