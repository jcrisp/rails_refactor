require 'test_helper'

class DummiesHelperTest < ActionView::TestCase
end
