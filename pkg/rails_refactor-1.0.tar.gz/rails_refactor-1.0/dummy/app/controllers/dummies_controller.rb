class DummiesController < ApplicationController
  def index
  end

end
