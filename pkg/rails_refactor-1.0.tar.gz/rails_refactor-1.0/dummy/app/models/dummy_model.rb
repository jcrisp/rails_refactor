class DummyModel < ActiveRecord::Base
end
