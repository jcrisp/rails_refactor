# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Dummy::Application.config.secret_token = 'df97448ae2b30197b0c5cb13d0fd9a38898b5636a0d0b8dfbdf8e41a852151d6df04473c54d31e42213b01acbbc93f043674c414205001a6a04c4b1a2cad9e76'
